<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PosSeeder extends Seeder
{
    public function run()
    {
        $this->db->table('products')->insertBatch([
            ['name' => 'Coffee', 'sku' => 'COF-001', 'price' => 85, 'stock' => 20, 'created_at' => date('Y-m-d H:i:s')],
            ['name' => 'Milk Tea', 'sku' => 'MT-001', 'price' => 110, 'stock' => 15, 'created_at' => date('Y-m-d H:i:s')],
            ['name' => 'Chocolate Cake', 'sku' => 'CK-001', 'price' => 150, 'stock' => 8, 'created_at' => date('Y-m-d H:i:s')],
        ]);
    }
}
