<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a>
        <nav class="main-nav">
            <a href="<?= base_url('/') ?>">Today</a>
            <a href="<?= base_url('tasks') ?>">Task List</a>
            <a href="<?= base_url('customers') ?>" class="active">Customers</a>
            <a href="<?= base_url('users') ?>">Users</a>
            <a href="<?= base_url('profile') ?>">Profile</a>
            <a href="<?= base_url('about') ?>">About</a><a href="<?= base_url('logout') ?>">Logout</a>
        </nav>
    </div>
</header>
<main class="page-container">
    <div class="page-heading page-heading-row">
        <div><h1>Customer Accounts</h1><p>Create and edit customer information.</p></div>
        <a class="button" href="<?= base_url('customers/new') ?>">+ New Customer</a>
    </div>
    <section class="table-card">
        <table>
            <thead><tr><th>Full Name</th><th>Email</th><th>Phone</th><th>Action</th></tr></thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                <tr>
                    <td><?= esc($customer['full_name']) ?></td>
                    <td><?= esc($customer['email']) ?></td>
                    <td><?= esc($customer['phone']) ?></td>
                    <td><a class="table-link" href="<?= base_url('customers/edit/' . $customer['id']) ?>">Edit</a> <form method="post" action="<?= base_url('customers/delete/' . $customer['id']) ?>" style="display:inline" onsubmit="return confirm('Delete this customer?');"><?= csrf_field() ?><button class="table-link table-button" type="submit">Delete</button></form></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>
<footer class="site-footer">Tasks for Today Management System</footer>
</body>
</html>
