<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($formTitle) ?> | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header"><div class="header-content"><a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a><nav class="main-nav"><a href="<?= base_url('/') ?>">Today</a><a href="<?= base_url('tasks') ?>">Task List</a><a href="<?= base_url('customers') ?>">Customers</a><a href="<?= base_url('users') ?>">Users</a><a href="<?= base_url('profile') ?>">Profile</a><a href="<?= base_url('logout') ?>">Logout</a></nav></div></header>
<main class="page-container form-page">
    <div class="page-heading"><h1><?= esc($formTitle) ?></h1><p>Enter the task details below.</p></div>
    <form class="form-card" method="post">
        <?= csrf_field() ?>
        <?php if ($errors): ?><div class="form-errors"><ul><?php foreach ($errors as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <label for="title">Task title</label>
        <input id="title" name="title" type="text" value="<?= esc(old('title', $task['title'] ?? '')) ?>">
        <label for="status">Status</label>
        <select id="status" name="status">
            <?php $status = old('status', $task['status'] ?? 'pending'); ?>
            <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending</option>
            <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>Completed</option>
        </select>
        <label for="task_date">Task date</label>
        <input id="task_date" name="task_date" type="date" value="<?= esc(old('task_date', $task['task_date'] ?? date('Y-m-d'))) ?>">
        <div class="form-actions"><a class="button secondary" href="<?= base_url('tasks') ?>">Cancel</a><button class="button" type="submit">Save Task</button></div>
    </form>
</main>
</body>
</html>
