<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in | TaskFlow POS</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body class="login-page">
    <main class="login-card">
        <div class="login-mark">TF</div>
        <p class="eyebrow">TaskFlow POS</p>
        <h1>Welcome back</h1>
        <p class="login-subtitle">Log in to manage your customers and users.</p>

        <?php if (! empty($errors)): ?>
            <div class="form-errors">
                <?php foreach ($errors as $error): ?>
                    <p><?= esc($error) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('login') ?>" method="post" class="stack-form">
            <?= csrf_field() ?>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" value="<?= old('username') ?>" autocomplete="username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" autocomplete="current-password" required>

            <button type="submit" class="button login-button">Log In</button>
        </form>
    </main>
</body>
</html>
