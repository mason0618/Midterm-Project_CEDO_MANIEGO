<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Tasks extends BaseController
{
    public function index()
    {
        $taskModel = new TaskModel();

        $data['tasks'] = $taskModel
            ->orderBy('task_date', 'ASC')
            ->orderBy('created_at', 'ASC')
            ->where('is_archived', 0)
            ->findAll();

        return view('tasks', $data);
    }

    public function new()
    {
        $data = ['formTitle' => 'New Task', 'task' => [], 'errors' => []];

        if ($this->request->getMethod() === 'POST') {
            $rules = ['title' => 'required|max_length[150]', 'task_date' => 'required|valid_date[Y-m-d]'];

            if (! $this->validate($rules)) {
                $data['errors'] = service('validation')->getErrors();
                $data['task'] = $this->request->getPost();
            } else {
                (new TaskModel())->insert([
                    'title' => trim($this->request->getPost('title')),
                    'status' => $this->request->getPost('status') ?: 'pending',
                    'task_date' => $this->request->getPost('task_date'),
                    'created_at' => date('Y-m-d H:i:s'),
                    'is_archived' => 0,
                ]);

                return redirect()->to('/tasks');
            }
        }

        return view('task_form', $data);
    }

    public function edit(int $id)
    {
        $model = new TaskModel();
        $task = $model->find($id);

        if (! $task || $task['is_archived']) {
            return redirect()->to('/tasks');
        }

        $data = ['formTitle' => 'Edit Task', 'task' => $task, 'errors' => []];

        if ($this->request->getMethod() === 'POST') {
            $rules = ['title' => 'required|max_length[150]', 'task_date' => 'required|valid_date[Y-m-d]'];

            if (! $this->validate($rules)) {
                $data['errors'] = service('validation')->getErrors();
                $data['task'] = array_merge($task, $this->request->getPost());
            } else {
                $model->update($id, [
                    'title' => trim($this->request->getPost('title')),
                    'status' => $this->request->getPost('status') ?: 'pending',
                    'task_date' => $this->request->getPost('task_date'),
                ]);

                return redirect()->to('/tasks');
            }
        }

        return view('task_form', $data);
    }

    public function delete(int $id)
    {
        $model = new TaskModel();

        if ($model->find($id)) {
            $model->update($id, ['is_archived' => 1]);
        }

        return redirect()->to('/tasks');
    }
}
