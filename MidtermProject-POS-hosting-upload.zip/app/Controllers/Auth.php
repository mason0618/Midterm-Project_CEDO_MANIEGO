<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        $errors = [];

        if ($this->request->getMethod() === 'POST') {
            $rules = [
                'username' => 'required',
                'password' => 'required',
            ];

            if (! $this->validate($rules)) {
                $errors = service('validation')->getErrors();
            } else {
                $user = (new UserModel())
                    ->where('username', $this->request->getPost('username'))
                    ->first();

                if ($user && password_verify($this->request->getPost('password'), $user['password'])) {
                    session()->regenerate();
                    session()->set([
                        'isLoggedIn' => true,
                        'userId' => $user['id'],
                        'username' => $user['username'],
                    ]);

                    return redirect()->to('/customers');
                }

                $errors['login'] = 'The username or password is incorrect.';
            }
        }

        return view('login', ['errors' => $errors]);
    }

    public function logout()
    {
        session()->destroy();

        return redirect()->to('/login');
    }
}
