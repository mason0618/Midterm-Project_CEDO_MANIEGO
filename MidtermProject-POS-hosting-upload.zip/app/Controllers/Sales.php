<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\ProductModel;
use App\Models\SaleModel;

class Sales extends BaseController
{
    public function index()
    {
        $sales = (new SaleModel())->select('sales.*, customers.full_name AS customer_name, users.full_name AS staff_name')
            ->join('customers', 'customers.id = sales.customer_id')
            ->join('users', 'users.id = sales.staff_id')
            ->orderBy('sales.created_at', 'DESC')->findAll();

        return view('sales', ['sales' => $sales]);
    }

    public function new()
    {
        $productModel = new ProductModel();
        $data = [
            'products' => $productModel->where('stock >', 0)->orderBy('name')->findAll(),
            'customers' => (new CustomerModel())->orderBy('full_name')->findAll(),
            'errors' => [],
        ];

        if (strtolower($this->request->getMethod()) === 'post') {
            $rules = [
                'product_id' => 'required|is_not_unique[products.id]',
                'customer_id' => 'required|is_not_unique[customers.id]',
                'quantity' => 'required|integer|greater_than[0]',
            ];

            if ($this->validate($rules)) {
                $product = $productModel->find($this->request->getPost('product_id'));
                $quantity = (int) $this->request->getPost('quantity');

                if ($product && $product['stock'] >= $quantity) {
                    $total = (float) $product['price'] * $quantity;
                    $db = db_connect();
                    $db->transStart();
                    $saleModel = new SaleModel();
                    $saleModel->insert([
                        'customer_id' => $this->request->getPost('customer_id'),
                        'staff_id' => session()->get('userId'),
                        'total' => $total,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                    $saleId = $saleModel->getInsertID();
                    $db->table('sale_items')->insert([
                        'sale_id' => $saleId,
                        'product_id' => $product['id'],
                        'quantity' => $quantity,
                        'price' => $product['price'],
                        'total' => $total,
                    ]);
                    $productModel->update($product['id'], ['stock' => $product['stock'] - $quantity]);
                    $db->transComplete();

                    if ($db->transStatus()) {
                        return redirect()->to('/sales');
                    }
                } else {
                    $data['errors']['quantity'] = 'There is not enough stock for this sale.';
                }
            } else {
                $data['errors'] = service('validation')->getErrors();
            }
        }

        return view('sale_form', $data);
    }
}
