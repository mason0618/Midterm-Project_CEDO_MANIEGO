<?php

namespace App\Controllers;

use App\Models\ProductModel;

class Products extends BaseController
{
    public function index()
    {
        return view('products', ['products' => (new ProductModel())->orderBy('name')->findAll()]);
    }

    public function new()
    {
        return $this->saveProduct();
    }

    public function edit(int $id)
    {
        return $this->saveProduct($id);
    }

    private function saveProduct(?int $id = null)
    {
        $model = new ProductModel();
        $product = $id ? $model->find($id) : null;
        $errors = [];

        if ($id && ! $product) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if (strtolower($this->request->getMethod()) === 'post') {
            $rules = [
                'name' => 'required|max_length[100]',
                'sku' => $id ? "required|max_length[50]|is_unique[products.sku,id,{$id}]" : 'required|max_length[50]|is_unique[products.sku]',
                'price' => 'required|decimal|greater_than_equal_to[0]',
                'stock' => 'required|integer|greater_than_equal_to[0]',
                'image' => 'permit_empty|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/png]|max_size[image,2048]',
            ];

            if ($this->validate($rules)) {
                $data = [
                    'name' => trim($this->request->getPost('name')),
                    'sku' => trim($this->request->getPost('sku')),
                    'price' => $this->request->getPost('price'),
                    'stock' => $this->request->getPost('stock'),
                ];

                $file = $this->request->getFile('image');
                if ($file && $file->isValid() && ! $file->hasMoved()) {
                    $filename = bin2hex(random_bytes(8)) . '.' . $file->getExtension();
                    $path = FCPATH . 'uploads';
                    if (! is_dir($path)) {
                        mkdir($path, 0775, true);
                    }
                    service('image')->withFile($file->getTempName())->fit(400, 400)->save($path . DIRECTORY_SEPARATOR . $filename);
                    $data['image'] = $filename;
                }

                if ($id) {
                    $model->update($id, $data);
                } else {
                    $data['created_at'] = date('Y-m-d H:i:s');
                    $model->insert($data);
                }

                return redirect()->to('/products');
            }

            $errors = service('validation')->getErrors();
            $product = array_merge($product ?? [], $this->request->getPost());
        }

        return view('product_form', ['product' => $product, 'formTitle' => $id ? 'Edit Product' : 'New Product', 'errors' => $errors]);
    }

    public function delete(int $id)
    {
        (new ProductModel())->delete($id);
        return redirect()->to('/products');
    }
}
