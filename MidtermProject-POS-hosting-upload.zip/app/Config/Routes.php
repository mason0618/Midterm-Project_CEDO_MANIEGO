<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Pages::home');
$routes->get('/about', 'Pages::about');
$routes->get('/tasks', 'Tasks::index');
$routes->match(['get', 'post'], '/tasks/new', 'Tasks::new');
$routes->match(['get', 'post'], '/tasks/edit/(:num)', 'Tasks::edit/$1');
$routes->post('/tasks/delete/(:num)', 'Tasks::delete/$1');
$routes->get('/products', 'Products::index');
$routes->match(['get', 'post'], '/products/new', 'Products::new');
$routes->match(['get', 'post'], '/products/edit/(:num)', 'Products::edit/$1');
$routes->post('/products/delete/(:num)', 'Products::delete/$1');
$routes->get('/sales', 'Sales::index');
$routes->match(['get', 'post'], '/sales/new', 'Sales::new');
$routes->get('/profile', 'Profile::index');
$routes->match(['get', 'post'], '/login', 'Auth::login');
$routes->get('/logout', 'Auth::logout');
$routes->get('/customers', 'Customers::index');
$routes->match(['get', 'post'], '/customers/new', 'Customers::new');
$routes->match(['get', 'post'], '/customers/edit/(:num)', 'Customers::edit/$1');
$routes->post('/customers/delete/(:num)', 'Customers::delete/$1');
$routes->get('/users', 'Users::index');
$routes->match(['get', 'post'], '/users/new', 'Users::new');
$routes->match(['get', 'post'], '/users/edit/(:num)', 'Users::edit/$1');
$routes->post('/users/delete/(:num)', 'Users::delete/$1');
