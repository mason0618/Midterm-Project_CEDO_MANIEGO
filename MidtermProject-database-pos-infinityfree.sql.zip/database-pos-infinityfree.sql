SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS sale_items;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE tasks (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(150) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', task_date DATE NOT NULL, created_at DATETIME NOT NULL, is_archived TINYINT(1) NOT NULL DEFAULT 0);
CREATE TABLE customers (id INT AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL, phone VARCHAR(20), created_at DATETIME NOT NULL);
CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, full_name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL, password VARCHAR(255) NOT NULL, avatar VARCHAR(255), created_at DATETIME NOT NULL);
CREATE TABLE products (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, sku VARCHAR(50) NOT NULL UNIQUE, price DECIMAL(10,2) NOT NULL DEFAULT 0, stock INT NOT NULL DEFAULT 0, image VARCHAR(255), created_at DATETIME NOT NULL);
CREATE TABLE sales (id INT AUTO_INCREMENT PRIMARY KEY, customer_id INT NOT NULL, staff_id INT NOT NULL, total DECIMAL(10,2) NOT NULL, created_at DATETIME NOT NULL, FOREIGN KEY (customer_id) REFERENCES customers(id), FOREIGN KEY (staff_id) REFERENCES users(id));
CREATE TABLE sale_items (id INT AUTO_INCREMENT PRIMARY KEY, sale_id INT NOT NULL, product_id INT NOT NULL, quantity INT NOT NULL, price DECIMAL(10,2) NOT NULL, total DECIMAL(10,2) NOT NULL, FOREIGN KEY (sale_id) REFERENCES sales(id), FOREIGN KEY (product_id) REFERENCES products(id));

INSERT INTO tasks (title, status, task_date, created_at) VALUES ('Review project requirements', 'completed', CURDATE(), NOW()), ('Finish the database setup', 'pending', CURDATE(), NOW()), ('Test the task list page', 'pending', CURDATE(), NOW()), ('Prepare the project documentation', 'pending', CURDATE(), NOW()), ('Check yesterday''s completed tasks', 'completed', DATE_SUB(CURDATE(), INTERVAL 1 DAY), NOW()), ('Organize the project files', 'pending', DATE_SUB(CURDATE(), INTERVAL 1 DAY), NOW()), ('Plan next week''s tasks', 'pending', DATE_ADD(CURDATE(), INTERVAL 1 DAY), NOW()), ('Present the working system', 'pending', DATE_ADD(CURDATE(), INTERVAL 2 DAY), NOW());
INSERT INTO customers (full_name, email, phone, created_at) VALUES ('Juan Dela Cruz', 'juan@example.com', '09171234567', NOW()), ('Maria Santos', 'maria@example.com', '09181234567', NOW()), ('Carlo Reyes', 'carlo@example.com', '09191234567', NOW()), ('Angela Garcia', 'angela@example.com', '09201234567', NOW()), ('Miguel Mendoza', 'miguel@example.com', '09211234567', NOW());
INSERT INTO users (username, full_name, email, password, avatar, created_at) VALUES ('mason', 'Mason Andrei Cedo', 'masonandrei@gmail.com', '$2y$10$Kdu9AJZZSOoT0AFHxz432O26CcsdUd0ycRsqqSJSv1swYlimAIbwG', NULL, NOW());
INSERT INTO products (name, sku, price, stock, image, created_at) VALUES ('Coffee', 'COF-001', 85.00, 20, NULL, NOW()), ('Milk Tea', 'MT-001', 110.00, 15, NULL, NOW()), ('Chocolate Cake', 'CK-001', 150.00, 8, NULL, NOW());
